<?php
// specialproduct.php

$servername = "localhost"; // or your database server
$username = "root";        // your MySQL username
$password = "";            // your MySQL password
$dbname = "bilum_store";   // your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $details = $_POST['details'];
    $price = $_POST['price'];
    $image = $_FILES['image'];

    // Validate and upload the image
    $target_dir = "uploads/"; // Make sure this directory exists and is writable
    $target_file = $target_dir . basename($image["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $allowed_types = ['jpg', 'png', 'jpeg', 'gif'];

    if (in_array($imageFileType, $allowed_types) && move_uploaded_file($image["tmp_name"], $target_file)) {
        // Insert product into the database
        $sql = "INSERT INTO specialproducts(name, details, price, image_path) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssis", $name, $details, $price, $target_file);

        if ($stmt->execute()) {
            echo "Product added successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Invalid file type or error uploading file.";
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Add Special Product</title>
    <style>
        body {
            margin: 0 2%; /* Set left and right margin for body */
            font-family: Arial, sans-serif;
            background-color: lightcyan;
            display: flex;
            flex-direction: column;
            align-items: center; /* Center content */
            padding-top: 60px; /* Space for fixed header */
            padding-bottom: 60px; /* Space for fixed footer */
        }
        header, footer {
            background-color:lightseagreen;
            color: white;
            text-align: center;
            padding: 5px; /* Reduced padding for header and footer */
            width: 100%; /* Full width for header and footer */
            position: fixed; /* Fixed positioning */
            left: 0;
            z-index: 1000; /* Ensure it sits above other content */
            display: flex;
            align-items: center; /* Center vertically */
        }
        header {
            top: 0; /* Position at the top */
        }
        footer {
            bottom: 0; /* Position at the bottom */
        }
        .back-icon {
            margin-right: auto; /* Push back icon to the left */
            padding-left: 10px; /* Space from the left edge */
            cursor: pointer;
            font-size: 1.5em; /* Size of the back icon */
        }
        h1 {
            font-size: 1.5em; /* Smaller font size for header title */
            margin: 0; /* Remove margin */
        }
        p {
            font-size: 0.9em; /* Smaller font size for header subtitle */
            margin: 0; /* Remove margin */
        }
        h2 {
            margin-top: 80px; /* Spacing for heading */
        }
        form {
            background-color: white;
            border-radius: 8px;
            padding: 15px; /* Standard padding for form */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px; /* Max width for form */
        }
        label {
            display: block;
            margin-top: 8px; /* Margin for labels */
        }
        input, textarea, button {
            width: calc(100% - 16px); /* Full width minus padding */
            margin-top: 5px;
            padding: 8px; /* Standard padding for inputs */
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea {
            height: 60px; /* Consistent height for textarea */
            resize: none; /* Prevent resizing */
        }
        button {
            background-color: goldenrod;
            color: white;
            border: none;
            cursor: pointer;
            padding: 8px; /* Standard padding for button */
        }
        button:hover {
            background-color: darkgoldenrod;
        }
        @media (max-width: 768px) {
            body {
                margin: 0 2%; /* Keep left and right margin for smaller screens */
            }
            h2 {
                margin-top: 60px; /* Adjust heading margin for mobile */
            }
            form {
                max-width: 90%; /* Allow form to take up more width on smaller screens */
            }
            input, textarea, button {
                padding: 12px; /* Increase padding for touch targets */
            }
        }
        @media (max-width: 480px) {
            form {
                max-width: 95%; /* Max width for very small screens */
            }
        }
    </style>
</head>
<body>
    <header>
        <span class="back-icon" onclick="history.back();">←</span> <!-- Back icon -->
        <h1>Bilum Store</h1>
        <p>Your source for special products</p>
    </header>

    <h2>Add Special Product</h2>
    <form action="specialproduct.php" method="POST" enctype="multipart/form-data">
        <label for="name">Product Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="details">Product Details:</label>
        <textarea id="details" name="details" required></textarea>

        <label for="price">Price (PGK):</label>
        <input type="number" id="price" name="price" step="0.01" required>

        <label for="image">Upload Image:</label>
        <input type="file" id="image" name="image" accept="image/*" required>

        <button type="submit">Add Product</button>
    </form>

    <footer>
        <p>&copy; 2024 Bilum Store</p>
    </footer>
</body>
</html>
