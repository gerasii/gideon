<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bilum Store - Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: lightseagreen;
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .header, .footer {
            background-color: lightblue;
            color: white;
            text-align: center;
            padding: 10px;
        }
        .container {
            background-color: lightskyblue;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 90%;
            width: 400px;
            padding: 20px;
            box-sizing: border-box;
            margin: auto;
            flex: 1;
            max-height: 500px;
            overflow: auto;
        }
        .logo {
            width: 250px;
            margin: 20px auto;
            max-width: 100%;
            height: auto;
            display: block;
            transition: transform 0.3s ease;
            cursor: pointer;
        }
        .logo.enlarged {
            transform: scale(2); /* Adjust scale factor as needed */
        }
        h2 {
            margin-top: 0;
            color: blue;
            font-size: 28px;
            text-align: center;
        }
        h3 {
            color: blue;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }

        @media (max-width: 600px) {
            .container {
                padding: 15px;
                width: 90%;
            }
            .logo {
                width: 100px;
            }
            h2 {color: blue;
                font-size: 24px;
            }
            input[type="submit"] {
                font-size: 16px;
            }
        }
        
        @media (max-width: 400px) {
            input[type="text"],
            input[type="password"] {
                padding: 8px;
            }
            input[type="submit"] {
                padding: 8px;
            }
            h2 {color:blue;
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h3>Welcome to the SHP, Ialibu Bilum Store</h3>
    </div>

    <div class="container">
        <img src="images/ibv.png" alt="Logo" class="logo" id="logo" onclick="enlargeLogo()">
    
        <h2>Login</h2>
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="post" action="dashboard.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" value="Login">
        </form>
    </div>

    <div class="footer">
    <p>&copy; <?= date("Y") ?> Local Bilum Vendor. All Rights Reserved |Developed by JarlKarl.</p>

    </div>

    <script>
        function enlargeLogo() {
            const logo = document.getElementById('logo');
            logo.classList.toggle('enlarged');
        }
    </script>
</body>
</html>
