<?php
session_start();

// Database connection
$servername = "localhost"; // or your database server
$username = "root";     // your MySQL username
$password = ""; // your MySQL password
$dbname = "bilum_store";   // your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products from the database
$result = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: lightcyan;
            font-family: Arial, sans-serif;
            margin: 1.5%;
            padding: 0;
            line-height: 1.6;
        }

        header {
            background-color: lightseagreen;
            padding: 10px 0;
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-left: 10px;
            font-size: 1.5em;
            color: #000;
        }

        h1 {
            font-size: 1.5em;
            margin: 0;
            flex-grow: 1;
            text-align: center;
        }

        nav ul {
            background-color: goldenrod;
            list-style: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        h2, h3 {
            color: #333;
        }

        footer {
            text-align: center;
            padding: 10px 0;
            background: lightseagreen;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
        }

        .product-item {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            text-align: center;
            background-color: white;
            cursor: pointer;
        }

        .product-item img {
            width: 100%;
            height: auto;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .modal img {
            max-width: 90%;
            max-height: 90%;
        }

        .modal-content {
            color: white;
        }

        .close {
            position: absolute;
            top: 20px;
            right: 30px;
            color: white;
            font-size: 40px;
            cursor: pointer;
        }

        footer a {
            margin: 0 10px;
        }

        @media (min-width: 600px) {
            nav ul li {
                display: inline-block;
            }
        }
    </style>
</head>
<body>
    <header>
        <a href="index.php" style="text-decoration: none;">
            <i class="fas fa-arrow-left back-icon"></i>
        </a>
        <h1>Locally Crafted Bilum Sales</h1>
    </header>
    
    <main>
        <h2>Available Products</h2>
        <div class="product-grid">
        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='product-item' onclick=\"showModal('" . htmlspecialchars($row['image_path']) . "', '" . htmlspecialchars($row['image_name']) . "', '" . htmlspecialchars($row['image_details']) . "', " . htmlspecialchars($row['price']) . ")\">";
                echo "<img src='" . htmlspecialchars($row['image_path']) . "' alt='" . htmlspecialchars($row['image_name']) . "'>";
                echo "<h4>" . htmlspecialchars($row['image_name']) . "</h4>";
                echo "<p>" . htmlspecialchars($row['image_details']) . "</p>";
                echo "<p>K" . htmlspecialchars(number_format($row['price'], 2)) . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>No products found.</p>";
        }
        ?>
        </div>

        <!-- Modal for Enlarged Image -->
        <div class="modal" id="imageModal">
            <span class="close" onclick="closeModal()">&times;</span>
            <div class="modal-content">
                <img id="modalImage" src="" alt="">
                <h4 id="modalTitle"></h4>
                <p id="modalDetails"></p>
                <p id="modalPrice"></p>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; <?= date("Y") ?> Local Bilum Vendor. All Rights Reserved |Developed by JarlKarl.</p>
        <a href="https://wa.me/your_phone_number" target="_blank">
            <img src="https://img.icons8.com/ios-filled/50/000000/whatsapp.png" alt="WhatsApp" style="width:30px; height:auto;">
        </a>
        <a href="mailto:your_email@example.com" target="_blank">
            <img src="https://img.icons8.com/material-outlined/50/000000/gmail-new.png" alt="Gmail" style="width:30px; height:auto;">
        </a>
    </footer>

    <script>
        function showModal(imageSrc, title, details, price) {
            document.getElementById('modalImage').src = imageSrc;
            document.getElementById('modalTitle').innerText = title;
            document.getElementById('modalDetails').innerText = details;
            document.getElementById('modalPrice').innerText = "K" + price.toFixed(2);
            document.getElementById('imageModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('imageModal').style.display = 'none';
        }

        // Close the modal when clicking outside of the image
        window.onclick = function(event) {
            const modal = document.getElementById('imageModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>
