<?php
// viewspecialproducts.php

$servername = "localhost"; // or your database server
$username = "root";        // your MySQL username
$password = "";            // your MySQL password
$dbname = "bilum_store";   // your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch special products
$sql = "SELECT name, details, price, image_path FROM  specialproducts"; // Adjust query if you want to filter special products
$result = $conn->query($sql);

// Check if the query was successful
if (!$result) {
    die("Query failed: " . $conn->error); // This will give you the specific error
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Special Products</title>
    <style>
        /* Add your styles here */
        .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 20px;
        }
        .gallery-item {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            flex: 1 1 calc(25% - 15px);
        }
        .gallery-item img {
            max-width: 100%;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <h2>Special Products</h2>
    <div class="gallery">
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo '<div class="gallery-item">';
                echo '<img src="' . htmlspecialchars($row['image_path']) . '" alt="' . htmlspecialchars($row['name']) . '">';
                echo '<h3>' . htmlspecialchars($row['name']) . '</h3>';
                echo '<p>' . htmlspecialchars($row['details']) . '</p>';
                echo '<p>PGK ' . number_format($row['price'], 2) . '</p>';
                echo '</div>';
            }
        } else {
            echo '<p>No special products found.</p>';
        }

        // Close the connection
        $conn->close();
        ?>
    </div>
</body>
</html>
