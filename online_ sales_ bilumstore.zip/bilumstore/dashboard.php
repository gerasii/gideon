<?php
session_start();

$servername = "localhost"; // Change if needed
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "bilum_store"; // The name of the database you created

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the product addition form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_product'])) {
        $imageName = trim($_POST['image_name']);
        $imageDetails = trim($_POST['image_details']);
        $price = $_POST['price'];

        // Handle file upload
        $targetDir = "uploads/"; // Ensure this directory exists
        $targetFile = $targetDir . basename($_FILES["image_file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is an actual image
        $check = getimagesize($_FILES["image_file"]["tmp_name"]);
        if ($check === false) {
            $error = "File is not an image.";
            $uploadOk = 0;
        }

        // Check file size (500KB limit)
        if ($_FILES["image_file"]["size"] > 500000000000) {
            $error = "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        $allowedFormats = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($imageFileType, $allowedFormats)) {
            $error = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Attempt file upload
        if ($uploadOk == 1 && move_uploaded_file($_FILES["image_file"]["tmp_name"], $targetFile)) {
            // SQL query to insert product into the database
            $stmt = $conn->prepare("INSERT INTO products (image_name, image_details, price, image_path) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssds", $imageName, $imageDetails, $price, $targetFile);

            if ($stmt->execute()) {
                $success = "Product added successfully!";
            } else {
                $error = "Error adding product: " . $stmt->error;
            }
        } else {
            $error = $error ?? "Sorry, there was an error uploading your file.";
        }
    } elseif (isset($_POST['remove_product'])) {
        // Remove product functionality
        $productId = $_POST['product_id'];

        // Get the image path to delete the file
        $stmt = $conn->prepare("SELECT image_path FROM products WHERE id = ?");
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($imagePath);
        $stmt->fetch();
        
        if ($stmt->num_rows > 0) {
            // Delete the image file
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }

            // Delete the product from the database
            $deleteStmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            $deleteStmt->bind_param("i", $productId);
            if ($deleteStmt->execute()) {
                $success = "Product removed successfully!";
            } else {
                $error = "Error removing product: " . $deleteStmt->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: lightseagreen;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
            margin-left: 5%;
            margin-right: 5%;
        }

        header {
            background-color: lightblue;
            padding: 5px 0;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            color: blue;
            text-decoration: none;
        }

        .nav-icon {
            font-size: 0.8em; /* Smaller icon size */
            margin-right: 5px; /* Space between icon and text */
        }

        h1, h2, h3 {
            color: blue;
        }

        footer {
            text-align: center;
            padding: 10px 0;
            background: lightseagreen;
        }

        form {
            margin: 20px;
        }

        input, textarea, select, button {
            display: block;
            width: 100%;
            margin: 10px 0;
            padding: 10px;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 20px;
            padding: 20px 0;
        }

        .product-item {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            text-align: center;
            background-color: white;
        }

        .product-item img {
            width: 100%;
            height: auto;
        }

        .remove-btn {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        @media (min-width: 600px) {
            nav ul li {
                display: inline-block;
            }
        }
    </style>
</head>

<body>
    <header>
        <h4>Admin Dashboard</h4>
        <nav>
            <ul>
                <li><a href="index.php"><i class="fas fa-home nav-icon"></i></a></li>
                <li><a href="viewproducts.php"><i class="fas fa-box nav-icon"></i></a></li>
                <li><a href="aboutus.php"><i class="fas fa-info-circle nav-icon"></i></a></li>
                <li><a href="contact.php"><i class="fas fa-envelope nav-icon"></i></a></li>
                <li><a href="specialproduct.php"><i class="fas fa-star nav-icon"></i></a></li>
                <li><a href="login.php"><i class="fas fa-user-shield nav-icon"></i></a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h2>Add New Product</h2>
        <form method="POST" enctype="multipart/form-data">
            <label for="image_name">Product Name:</label>
            <input type="text" id="image_name" name="image_name" required><br>

            <label for="image_details">Product Details:</label>
            <textarea id="image_details" name="image_details" required></textarea><br>

            <label for="price">Price (PGK):</label>
            <input type="number" id="price" name="price" step="0.01" required><br>

            <label for="image_file">Image File:</label>
            <input type="file" id="image_file" name="image_file" accept="image/*" required><br>

            <input type="submit" name="add_product" value="Add Product">
        </form>

        <?php if (isset($success)): ?>
            <p style='color: green;'><?= htmlspecialchars($success) ?></p>
        <?php elseif (isset($error)): ?>
            <p style='color: red;'><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <h3>Current Products</h3>
        <div class="product-grid">
        <?php
        // Fetch and display products from the database
        $result = $conn->query("SELECT * FROM products");
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='product-item'>";
                echo "<img src='" . htmlspecialchars($row['image_path']) . "' alt='" . htmlspecialchars($row['image_name']) . "'>";
                echo "<h4>" . htmlspecialchars($row['image_name']) . "</h4>";
                echo "<p>" . htmlspecialchars($row['image_details']) . "</p>";
                echo "<p>K" . htmlspecialchars(number_format($row['price'], 2)) . "</p>";
                echo "<form method='POST' style='display:inline;'>";
                echo "<input type='hidden' name='product_id' value='" . $row['id'] . "'>";
                echo "<input type='submit' name='remove_product' value='Remove' class='remove-btn'>";
                echo "</form>";
                echo "</div>";
            }
        } else {
            echo "<p>No products found.</p>";
        }
        ?>
        </div>
    </main>

    <footer>
    <p>&copy; <?= date("Y") ?> Local Bilum Vendor. All Rights Reserved |Developed by JarlKarl.</p>

    </footer>
</body>
</html>
