<?php
// Start session and check for admin login
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

$products = json_decode(file_get_contents('products.json'), true);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_index = $_POST['product_index'];
    array_splice($products, $product_index, 1);
    file_put_contents('products.json', json_encode($products));
    echo "Product removed successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remove Product</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h3>Remove a Product</h3>
    </header>
    <main>
        <form method="POST">
            <label for="product_index">Select Product to Remove:</label>
            <select id="product_index" name="product_index">
                <?php foreach ($products as $index => $product): ?>
                    <option value="<?php echo $index; ?>"><?php echo $product['name']; ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Remove Product</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Bilum Store</p>
    </footer>
</body>
</html>
