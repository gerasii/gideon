<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome -->
    <title>Contact Us - Bilum Store</title>
    <style>
        body {
            background-color: lightcyan;
            margin: 0; /* Remove default margin */
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            text-align: center; /* Center all text content */
        }

        header {
            background-color:lightseagreen;
            color: white;
            text-align: center;
            padding: 10px; /* Reduced padding */
            position: fixed;
            width: 100%; /* Full width */
            top: 0;
            z-index: 1000;
        }

        nav {
            margin: 10px 0; /* Space between header and nav */
        }

        nav ul {
            list-style-type: none;
            padding: 0;
            display: flex; /* Flexbox to arrange items in a row */
            justify-content: center; /* Center the nav items */
            flex-wrap: wrap; /* Wrap items on smaller screens */
        }

        nav ul li {
            margin: 0 15px; /* Space between nav items */
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: flex;
            align-items: center; /* Center icons vertically */
        }

        nav ul li a i {
            margin-right: 5px; /* Space between icon and text */
        }

        nav ul li a:hover {
            text-decoration: underline;
        }

        main {
            padding: 100px 10% 60px; /* Adjusted padding for main */
            flex: 1;
        }

        footer {
            text-align: center;
            padding: 10px;
            background-color: lightseagreen;
            width: 100%; /* Full width */
            position: relative; /* Allows footer to be at the bottom of the page */
            margin-top: auto; /* Push footer to bottom */
        }

        h2{
            color: blue; /* Uniform color for headings */
        }
        h3{color:yellow;

        }

        .social-links {
            margin-top: 20px;
            display: flex;
            flex-wrap: wrap; /* Allow wrapping for smaller screens */
            justify-content: center; /* Center social media links */
            background: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet); /* Rainbow background */
            padding: 10px; /* Reduced padding */
            border-radius: 10px; /* Rounded corners */
            max-width: 90%; /* Limit width for larger screens */
            margin-left: auto; /* Center alignment */
            margin-right: auto; /* Center alignment */
        }

        .social-links a {
            margin: 5px; /* Reduced margin */
            text-decoration: none;
            color: blue; /* Default text color */
            font-weight: bold;
            display: flex;
            align-items: center;
            padding: 5px 10px; /* Reduced padding */
            border-radius: 5px; /* Rounded corners for each icon */
            transition: background-color 0.3s;
        }

        .social-links a i {
            margin-right: 5px; /* Space between icon and text */
        }

        /* Individual colors for each social media */
        .social-links a.facebook { color: blue; }
        .social-links a.youtube { color: red; }
        .social-links a.instagram { color: purple; }
        .social-links a.twitter { color: skyblue; }
        .social-links a.linkedin { color: #0077b5; }
        .social-links a.pinterest { color: red; }

        .social-links a:hover {
            background-color: rgba(255, 255, 255, 0.3); /* Light hover effect */
        }

        .contact-info i {
            margin-right: 8px; /* Space between icon and text */
        }

        @media (max-width: 600px) {
            nav ul li {
                margin: 0 5px; /* Reduced margin for mobile */
            }

            header {
                padding: 10px; /* Adjusted header padding for smaller screens */
            }

            .social-links {
                flex-direction: column; /* Stack icons vertically on small screens */
            }
        }
    </style>
</head>
<body>
    <header>
        <h3>Welcome to the SHP, Ialibu Bilum Store</h3>
        <nav>
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i></a></li>
                <li><a href="viewproducts.php"><i class="fas fa-shopping-bag"></i></a></li>
                <li><a href="about.php"><i class="fas fa-info-circle"></i></a></li>
                <li><a href="contact.php"><i class="fas fa-envelope"></i></a></li>
                <li><a href="login.php"><i class="fas fa-user-lock"></i></a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Contact Us</h2>
        <p>If you're interested in purchasing or ordering a locally handcrafted Bilum, please don't hesitate to reach out! We take pride in our unique designs and quality craftsmanship. <br><br>You can contact us via WhatsApp at <i class="fas fa-phone" style="color: blue;"></i> +675 74381130 for inquiries or to place an order. We’re here to help you find the perfect Bilum that reflects your style and supports our local artisans! Alternatively, feel free to click on the social media links to connect with us for updates and inspiration.<br><br>You can also email us at <i class="fas fa-envelope" style="color: red;"></i> info@bilumstore.com for any questions or custom requests. We're excited to assist you in your journey to find the ideal Bilum!</p>
        
        <h2>Email</h3>
        <p><i class="fas fa-envelope" style="color: red;"></i> info@bilumstore.com</p>

        <h2>Phone</h3>
        <p><i class="fas fa-phone" style="color: blue;"></i> +675 74381130</p>

        <h2>Follow Us on Social Media</h2>
        <div class="social-links">
            <a href="https://www.facebook.com/YourPage" target="_blank" class="facebook"><i class="fab fa-facebook"></i> Facebook</a>
            <a href="https://www.youtube.com/youtube.com/@ThePerfectCreation675" target="_blank" class="youtube"><i class="fab fa-youtube"></i> YouTube</a>
            <a href="https://www.instagram.com/YourProfile" target="_blank" class="instagram"><i class="fab fa-instagram"></i> Instagram</a>
            <a href="https://twitter.com/YourProfile" target="_blank" class="twitter"><i class="fab fa-twitter"></i> Twitter</a>
            <a href="https://www.linkedin.com/in/YourProfile" target="_blank" class="linkedin"><i class="fab fa-linkedin"></i> LinkedIn</a>
            <a href="https://www.pinterest.com/YourProfile" target="_blank" class="pinterest"><i class="fab fa-pinterest"></i> Pinterest</a>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Bilum Store</p>
    </footer>
</body>
</html>
