<?php
// login.php

$servername = "localhost"; // or your database server
$username = "root";        // your MySQL username
$password = "";            // your MySQL password
$dbname = "bilum_store";   // your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start(); // Start a session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome -->
    <title>Bilum Store</title>
    <style>
        body {
            background-color: lightcyan;
            margin: 10;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: lightseagreen;
            color: blue;
            display: flex;
            flex-direction: column; /* Stack items vertically */
            align-items: center;    /* Center items horizontally */
            padding: 10px;
        }

        nav {
            display: flex; /* Show navigation as flex */
            justify-content: center; /* Center the nav */
            width: 100%; /* Full width */
        }

        nav ul {
            display: flex; /* Keep items inline */
            list-style-type: none;
            padding: 10px;
            margin: 10;
        }

        nav ul li {
            margin: 1px;
            border-radius: 5px;
        }

        nav ul li a {
            color: yellow;
            text-decoration: none;
            font-weight: bold;
            display: flex;
            align-items: center;
            padding: 1.5px 2.5px;
        }

        nav ul li a i {
            margin-right: 1px;
        }

        header h4 {
            font-size: 18px;
            margin: 10px 0; /* Add some margin for spacing */
            text-align: center;
        }

        main {
            padding: 20px 5%;
            flex: 1;
        }

        footer {
            text-align: center;
            padding: 10px;
            background-color: lightseagreen;
            width: 100%;
        }

        .product-list {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 20px;
        }

        .product-item {
            flex: 1 1 calc(33.33% - 15px);
            position: relative;
            overflow: hidden;
            border-radius: 8px;
            transition: transform 0.3s;
            cursor: pointer;
            display: flex; /* Flex to keep image centered */
            justify-content: center; /* Center the image */
            align-items: center; /* Center the image */
        }

        .product-item img {
            width: 50%;
            height: auto;
            border-radius: 8px;
            display: block;
            transition: transform 0.3s;
            max-height: 200px; /* Set a max height for images */
            object-fit: cover; /* Ensure images cover the area */
            border: 3px solid lightseagreen; /* Add a border */
        }

        .product-item:hover img {
            transform: scale(1.05);
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1001;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.8);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
        }

        .modal-content img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        p {
            color: blue;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .product-item {
                flex: 1 1 calc(50% - 15px);
            }

            header h4 {
                font-size: 16px;
            }
        }

        @media (max-width: 480px) {
            .product-item {
                flex: 1 1 100%;
            }

            header h4 {color:blue;
                font-size: 18px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h4>Welcome to the Southern Highlands Province Ialibu Bilum Store</h4>
        <nav id="navMenu">
            <ul>
                <li><a href="viewproducts.php"></i>Latest Products</a></li>
                <li><a href="viewspecialproducts.php"></i> Special Products</a></li>          
                <li><a href="contact.php"></i> Contact</a></li> 
                <li><a href="aboutus.php"></i> About Us</a></li>            
                <li><a href="login.php"></i> Login</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h4>Featured Bilums</h4>
        <p>Discover beautiful handmade Bilums from local vendors! <br><br>
        Experience the vibrant culture of the Southern Highlands with
         our featured Bilums crafted by local vendors from Ialibu. Each
          Bilum tells a unique story, showcasing traditional weaving
           techniques passed down through generations.<br> <br> By choosing Ialibu Bilum vendors,
            you're not just purchasing a product; you're supporting local artisans and their 
            families. Discover the beauty and craftsmanship that reflects the spirit of our community!</p>
            <br><br>
        
        <div class="product-list">
            <?php
            // Query to fetch products
            $sql = "SELECT image_path, price FROM products";
            $result = $conn->query($sql);

            if (!$result) {
                die("Query failed: " . $conn->error); // Display SQL error
            }

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo '<div class="product-item" onclick="openModal(\'' . $row['image_path'] . '\', \'\', \'' . $row['price'] . '\')">';
                    echo '<img src="' . $row['image_path'] . '" alt="Bilum Image" loading="lazy" style="transition: opacity 0.5s;">'; // Lazy loading
                    echo '</div>';
                }
            } else {
                echo '<p>No products found.</p>';
            }

            // Close the connection
            $conn->close();
            ?>
        </div>
    </main>
    <footer>
    <p>&copy; <?= date("Y") ?> Local Bilum Vendor. All Rights Reserved |Developed by JarlKarl.</p>

    </footer>

    <!-- Modal for Products -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <img id="modalImage" src="" alt="">
            <h3 id="modalTitle"></h3>
            <p id="modalPrice"></p>
        </div>
    </div>

    <script>
        function openModal(imageSrc, title, price) {
            document.getElementById('modalImage').src = imageSrc;
            document.getElementById('modalTitle').innerText = title;
            document.getElementById('modalPrice').innerText = price;
            document.getElementById('myModal').style.display = 'flex'; // Show modal
        }

        function closeModal() {
            document.getElementById('myModal').style.display = 'none'; // Hide modal
        }

        // Close the modal when the user clicks anywhere outside of it
        window.onclick = function(event) {
            const modal = document.getElementById('myModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>
