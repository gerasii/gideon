<?php
// Start session and check for admin login
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle form submission
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_FILES['product_image']['name'];

    // Move uploaded file to images directory
    move_uploaded_file($_FILES['product_image']['tmp_name'], 'images/' . $product_image);

    // Save product to a file or database (Here we'll use a JSON file for simplicity)
    $products = json_decode(file_get_contents('products.json'), true);
    $products[] = [
        'name' => $product_name,
        'price' => $product_price,
        'image' => $product_image
    ];
    file_put_contents('products.json', json_encode($products));

    echo "Product added successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h3>Add a New Product</h3>
    </header>
    <main>
        <form method="POST" enctype="multipart/form-data">
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" required>
            <label for="product_price">Product Price:</label>
            <input type="text" id="product_price" name="product_price" required>
            <label for="product_image">Product Image:</label>
            <input type="file" id="product_image" name="product_image" required>
            <button type="submit">Add Product</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Bilum Store</p>
    </footer>
</body>
</html>
