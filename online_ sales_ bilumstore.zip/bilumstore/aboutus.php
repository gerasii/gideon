<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome -->
    <title>About Us - Bilum Store</title>
    <style>
        body {
            background-color:lightslategrey;
            margin: 0; /* Remove default margin */
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            text-align: center; /* Center all text content */
        }

        header {
            background-color: lightseagreen;
            color: blue;
            padding: 15px; /* Adjusted padding */
            position: fixed;
            width: 100%; /* Full width */
            top: 0;
            z-index: 1000;
        }

        nav {
            margin-top: 5px; /* Space between header text and nav */
        }

        nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex; /* Horizontal layout */
            justify-content: center; /* Center the items */
            flex-wrap: wrap; /* Wrap items on smaller screens */
        }

        nav ul li {
            margin: 0 8px; /* Space between items */
        }

        nav ul li a {
            color: yellow; /* Icon color */
            text-decoration: none; /* Remove underline */
            padding: 5px; /* Reduced padding for links */
            transition: background 0.3s; /* Smooth transition */
        }

        nav ul li a:hover {
            background: rgba(255, 255, 255, 0.2); /* Hover effect */
            border-radius: 4px; /* Rounded corners */
        }

        nav ul li i {
            font-size: 16px; /* Smaller icon size */
        }

        main {
            padding: 100px 10% 60px; /* Adjusted padding for main */
            flex: 1;
        }

        footer {
            text-align: center;
            padding: 15px;
            background-color: lightseagreen;
            width: 100%; /* Full width */
            position: relative; /* Allows footer to be at the bottom of the page */
            margin-top: auto; /* Push footer to bottom */
        }

        h2, h3{
            color: skyblue; /* Uniform color for headings and paragraphs */
        }
p{color: black;

}
        .profile {
            margin-top: 30px;
        }

        .profile img {
            width: 150px; /* Image size */
            border-radius: 50%; /* Circular image */
        }

        @media (max-width: 600px) {
            header {
                padding: 10px; /* Adjust header padding for smaller screens */
            }
            nav ul li {
                margin: 0 5px; /* Reduced margin for mobile */
            }
            nav ul li i {
                font-size: 14px; /* Further reduce icon size for mobile */
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the SHP, Ialibu Bilum Store</h1>
        <nav>
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i></a></li>
                <li><a href="viewproducts.php"><i class="fas fa-shopping-bag"></i></a></li>
                <li><a href="about.php"><i class="fas fa-info-circle"></i></a></li>
                <li><a href="contact.php"><i class="fas fa-envelope"></i></a></li>
                <li><a href="login.php"><i class="fas fa-user-lock"></i></a></li>
            </ul>
        </nav>
    </header>
   
    <main>
    <br><br>  
     
        <h2>About Us</h2>
        <p>Welcome to the Papua New Guinea Bilum Store!</p>
        <p>At the heart of our store is a vibrant community of local Bilum vendors dedicated to preserving the rich cultural heritage of Papua New Guinea. Bilums are traditional handwoven bags, intricately crafted by skilled artisans using age-old techniques passed down through generations. Each Bilum tells a unique story, reflecting the artistry and traditions of the various cultures across the diverse regions of Papua New Guinea.</p>
        
        <h3>Our Mission</h3>
        <p>We aim to support and uplift local artisans by providing them with a platform to showcase their beautiful creations. By purchasing a Bilum from us, you are not only acquiring a unique piece of art but also contributing to the livelihoods of these talented individuals and their families.</p>
        
        <h3>Quality and Craftsmanship</h3>
        <p>Every Bilum is made with love and care, utilizing natural fibers and dyes sourced from the local environment. Our vendors take pride in their craftsmanship, ensuring that each bag is not only functional but also a work of art. Whether you are looking for a vibrant accessory to complete your outfit or a practical bag for everyday use, our collection offers a wide variety of styles, colors, and designs.</p>
        
        <h3>Cultural Significance</h3>
        <p>Bilums hold great cultural significance in Papua New Guinea. Traditionally used for carrying personal items, they are also symbols of identity and heritage. Each design often incorporates patterns and colors that represent specific tribes or regions, making every piece unique.</p>
        
        <h3>Join Us on This Journey</h3>
        <p>We invite you to explore our collection and discover the beauty of Bilums. By supporting local vendors, you are helping to preserve the rich traditions of Papua New Guinea and empower communities to thrive. Thank you for being part of our journey to promote sustainable and ethical practices through the art of Bilum weaving.</p>

        <div class="profile">
            <h3>Meet Our Founder</h3>
            <img src="images/9.jpg" alt="Gideon Solomon">
            <p>Name: Karl Jarl</p>
            <p>Passionate about promoting Papua New Guinea's culture and supporting local artisans, Karl Jarl founded the Bilum Store to share the beauty of traditional crafts with the world.</p>
        </div>
        
    </main>

    <footer>
    <p>&copy; <?= date("Y") ?> Local Bilum Vendor. All Rights Reserved |Developed by JarlKarl.</p>

    </footer>
</body>
</html>
